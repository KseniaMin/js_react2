
import { Route, Routes } from "react-router-dom";
import { Index } from "./pages/";
import { Profile } from "./pages/profile";
import { SignUp } from "./pages/signup";
import { Posts } from "./pages/posts";
import './App.css'
import { Nav } from "./components/nav";

const App = () => (
  <Nav>
    <Routes>
      <Route element={<Index />} path='/' />
      <Route element={<Profile />} path='/profile'/>
      <Route element={<SignUp />} path='/signup'/>
      <Route element={<Posts />} path='/posts'/>
    </Routes>
  </Nav>

)

export default App;