import { Link } from "react-router-dom"

export const Nav = ({children}) => {
    return (
        <>
            <div style={{width: "100%", display: "flex", position: "fixed", top: 0, gap: "60px", padding: "20px", background: "#f6f5f7", borderBottom: "2px solid #FF416C", zIndex: 9999}}>
                <Link to="/posts" style={{ textDecoration: 'none' }}>
                    <div className="header" style={{fontSize: "20px", fontWeight: "700", color: "rgb(255, 75, 43)"}}>
                        Посты
                    </div>
                </Link>
                <Link to="/" style={{ textDecoration: 'none' }}>
                    <div className="header" style={{fontSize: "20px", fontWeight: "700", color: "rgb(255, 75, 43)"}}>
                        Вход
                    </div>
                </Link>
                <Link to="/signup" style={{ textDecoration: 'none' }}>
                    <div className="header" style={{fontSize: "20px", fontWeight: "700", color: "rgb(255, 75, 43)"}}>
                        Регистрация
                    </div>
                </Link>
            </div>  
            {children}      
        </>
    )
}