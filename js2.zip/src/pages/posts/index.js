import React, { useEffect, useState } from 'react';
import { Card, Col, Row } from 'antd'

export const Posts = () => {
    const [users, setUsers] = useState([])
    const [userPosts, setPosts] = useState([])

    const getData = () => {
        fetch('https://jsonplaceholder.typicode.com/users')
            .then(res => res.json())
            .then(res => {
                if (res && Array.isArray(res) && res.length > 0) {
                    setUsers(res)
                }
            })

        fetch('https://jsonplaceholder.typicode.com/posts')
            .then(resPost => resPost.json())
            .then(resPost => {
                if (resPost && Array.isArray(resPost) && resPost.length > 0) {
                    setPosts(resPost)
                }
            })
    }


    const loadUsers = () => {
        getData()
    }

    useEffect(() => {
        getData()
    }, [])

    const styles = {
        backgroundColor: '#FF416C'
    }
    return (
        <div style={{marginTop: "70px"}}>
            <h2>Ksenia.designer</h2>
            <div style={{ margin: 20 }}>
                {users.length > 0 &&
                    users.map(user => {
                        return (
                            <Card title={user.name} key={Math.random()} style={{ width: 800, margin: 10, marginLeft: 500 }} headStyle={{ backgroundColor: '#FF416C' }}>
                                <p style={{ fontFamily: 'Oswald' }}>Email: {user.email}</p>
                                <Row gutter={10}>
                                    {

                                        userPosts.filter(post => post.userId === user.id).map((post, ind) => {
                                            return (

                                                <Col span={50} key={ind}>
                                                    <Card title={post.title} bordered={true} style={{ margin: 10 }} headStyle={{ backgroundColor: '#FF416C' }}>
                                                        <p >{post.body} </p>
                                                    </Card>
                                                </Col>
                                            )
                                        }
                                        )
                                    }
                                </Row>
                            </Card>
                        )
                    })
                }
            </div>
        </div>
    )
}