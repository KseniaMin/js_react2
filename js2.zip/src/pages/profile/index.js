import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Box } from "@mui/material";

export const Profile = () => {

  const navigate = useNavigate();

  const dispath = useDispatch();

  const store = useSelector(state => state);

  const [currentUser, setCurrentUser] = useState(false);

  const exit = () => {
    dispath(({ type: "del" }));
    navigate("/");
  }

  useEffect(() => {

    const getCurrrentUser = () => {
      if (store.user.user.name != null) {
        setCurrentUser(store.user.user);
      } else {
        navigate("/");
      }
    }

    getCurrrentUser();
  }, []);

  return (
    <>
      <Box display="flex" alignItems="center" justifyContent="center" height="100vh">
        {currentUser && <Box display="flex" borderRadius="20px" boxShadow="0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22)" height="500px">
          <Box
            display="flex"
            flexDirection="column"
            alignItems="center"
            justifyContent="center"
            width="400px"
            padding="30px"
            gap="10px"
            className="overlay overlay_right"
          >
            <h1 style={{ color: "#FFF", textAlign: "center" }}>Уже уходите? Ждем вас снова!</h1>
            <button className="button2" onClick={exit}>Выход</button>
          </Box>
          <Box
            display="flex"
            flexDirection="column"
            alignItems="center"
            justifyContent="center"
            width="400px"
            padding="30px"
            gap="10px"
          >
            <Box width='100%' display="flex" flexDirection="column" alignItems="center" justifyContent="space-between">
              <h1 style={{ color: "#FF4B2B", margin: "10px", textAlign: "center"}}>Ваш акканут</h1>
              <img src="/user.svg" style={{width: "200px", height: "200px", margin: "20px 0"}}/>
              <Box display="flex" gap="60px">
                <span style={{ fontSize: "20px", color: "#FF4B2B" }}>Имя: <b>{currentUser.name}</b></span>
                <span style={{ fontSize: "20px", color: "#FF4B2B" }}>ID: <b>{currentUser.id}</b></span>                
              </Box>
            </Box>
          </Box>
        </Box>}
      </Box>
    </>


  );
}