
import { Route, Routes } from "react-router-dom";
import { Index } from "./pages/";
import { Profile } from "./pages/profile";
import { SignUp } from "./pages/signup";
import './App.css'

const App = () => (
  <>
    <Routes>
      <Route element={<Index />} path='/' />
      <Route element={<Profile />} path='/profile'/>
      <Route element={<SignUp />} path='/signup'/>
    </Routes>
  </>

)

export default App;