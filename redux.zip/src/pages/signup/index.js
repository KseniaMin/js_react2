import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Box } from "@mui/material";

export const SignUp = () => {

  const navigate = useNavigate();
  const dispath = useDispatch();
  const store = useSelector(state => state);

  const [name, setName] = useState("");
  const [password1, setPassword1] = useState("");
  const [password2, setPassword2] = useState("");

  const checkUser = () => {
    return store.users.users.find(v => v.name === name);
  }

  const register = () => {
    if (password1 !== password2) {
      alert("Введенные вами пароли не совпадают!");
      return;
    }

    let user = checkUser();

    if (!user) {
      dispath(({ type: "addnew", name: name, password: password1 }));
      alert("Пользователь создан!");
      setName("");
      setPassword1("");
      setPassword2("");
    } else {
      alert("Пользователь с таким именем уже есть!");
    }

  }

  return (
    <Box display="flex" alignItems="center" justifyContent="center" height="100vh">
      <Box display="flex" borderRadius="20px" boxShadow="0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22)" height="500px">
        <Box
          display="flex"
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
          width="400px"
          padding="30px"
          gap="10px"
          className="overlay overlay_right"
        >
          <h1 style={{ color: "#FFF", textAlign: "center" }}>Уже есть аккаунт? Войдите!</h1>
          <button className="button2" onClick={() => navigate("/")}>Вход</button>
        </Box>
        <Box
          display="flex"
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
          width="400px"
          padding="30px"
          gap="10px"
        >
          <h1 style={{ color: "#FF4B2B", margin: "10px"}}>Зарегистрируйтесь!</h1>
          <input className="input" placeholder="Ваш логин" value={name} onChange={(e) => setName(e.target.value)} />
          <input className="input" type="password" placeholder="Ваш пароль" value={password1} onChange={(e) => setPassword1(e.target.value)} />
          <input className="input" type="password" placeholder="Повторите пароль" value={password2} onChange={(e) => setPassword2(e.target.value)} />
          <button className="button" onClick={register} disabled={!name || !password1 || !password2}>ЗАРЕГИСТРИРОВАТЬСЯ</button>
        </Box>
      </Box>
    </Box>
  );
}