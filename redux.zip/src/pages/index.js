import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Box } from "@mui/material";

export const Index = () => {

  const navigate = useNavigate();
  const dispath = useDispatch();
  const store = useSelector(state => state);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const findUser = () => {
    return store.users.users.find(v => v.name === username && v.password === password);
  }

  const logIn = () => {
    let user = findUser();
    if (user) {
      dispath(({ type: "newuser", id: user.id, name: user.name, password: user.password }));
      navigate("/profile");
    } else {
      alert("Неверный логин или пароль!");
    }
  }


  return (
    <Box display="flex" alignItems="center" justifyContent="center" height="100vh">
      <Box display="flex" borderRadius="20px" boxShadow="0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22)" height="500px">
          <Box
            display="flex"
            flexDirection="column"
            alignItems="center"
            justifyContent="center"
            width="400px"
            padding="30px"
            gap="10px"
            borderRadius="0 20px 20px 0"
          >
            <h1 style={{ color: "#FF4B2B", margin: "10px"}}>Войдите в аккаунт!</h1>
            <input className="input" placeholder="Логин" value={username} onChange={(e) => setUsername(e.target.value)} />
            <input className="input" type="password" placeholder="Пароль" value={password} onChange={(e) => setPassword(e.target.value)} />
            <button className="button" onClick={logIn} disabled={!username || !password}>ВОЙТИ</button>
          </Box>
          <Box
            display="flex"
            flexDirection="column"
            alignItems="center"
            justifyContent="center"
            width="400px"
            padding="30px"
            gap="10px"
            className="overlay overlay_left"
          >
              <h1 style={{ color: "#FFF", textAlign: "center" }}>Еще нет аккаунта? Зарегистрируйтесь!</h1>
              <button className="button2" onClick={() => navigate("/signup")}>Регистрация</button>
          </Box>        
      </Box>
    </Box>
  );
}